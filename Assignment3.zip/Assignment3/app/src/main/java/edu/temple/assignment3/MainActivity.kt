package edu.temple.assignment3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nameEditText = findViewById<EditText>(R.id.name_edit_text)
        val emailEditText = findViewById<EditText>(R.id.email_edit_text)
        val programSpinner = findViewById<Spinner>(R.id.program_spinner)
        val passwordEditText = findViewById<EditText>(R.id.password_edit_text)
        val passwordConfirmationEditText = findViewById<EditText>(R.id.password_confirmation_edit_text)
        val saveButton = findViewById<Button>(R.id.save_button)
        val resultTextView = findViewById<TextView>(R.id.result_text_view)
        val resultTextView1 = findViewById<TextView>(R.id.result_text_view_1)
        val programs = arrayOf("Information Science", "Computer Science", "Math and CS", "Data Science", "Other")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, programs)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        programSpinner.adapter = adapter

        saveButton.setOnClickListener {
            val name = nameEditText.text.toString().trim()
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()
            val passwordConfirmation = passwordConfirmationEditText.text.toString().trim()

            if (name.isEmpty()) {
                nameEditText.setText("Name is required")
                return@setOnClickListener
            }
            if (email.isEmpty()) {
                emailEditText.setText("Email is required")
                return@setOnClickListener
            }
            if (password.isEmpty()) {
                passwordEditText.setText("Password is required")
                return@setOnClickListener
            }
            if (passwordConfirmation.isEmpty()) {
                passwordConfirmationEditText.setText("Password confirmation is required")
                return@setOnClickListener
            }
            if (password != passwordConfirmation) {
                resultTextView.text = "Passwords do not match"
                return@setOnClickListener
            }

            resultTextView.text = "$name, you are signed up!"
        }
    }
}
